var lastslidenum=[]
var safeid=""
var thisshape=""
var onceshape=[]
var before_slide=[]
var shuffledvector=[]               
var shuffledvectorbeg=0, shuffledvectorend=0

function getURLParameter(name) {
  return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
}

function getRandomInRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}


function anew(a=1){
	if (a!=1 ) {
		var ok = confirm("Вы действительно хотите начать всё заново?");
	} else ok=true;
	if (ok) document.location.replace("index.html");
}


function startgame() {
if (safeid>"") initsafe(safeid);
$('#slide1').hide()
toslide(2,2);
}


function returnslide(f) {
if (lastslidenum.length>0){
	$('#slide'+f).hide()	
	$('#slide'+lastslidenum.pop()).show()	
}
}

function SlidesShuffle(a=0,b=0){
	if(a==0 || b==0) {
	  shuffledvector=[];
	  shuffledvectorbeg=0;	
	  shuffledvectorend=0;
	  return;               
	}
   	var j;
	shuffledvectorbeg=b;	
	shuffledvectorend=a;
	for (var i=a;i <=b;i++){
      		j= getRandomInRange(a,i)
      		shuffledvector[i]=shuffledvector[j]
      		shuffledvector[j]=i
	}
}

function enterShuffled(){
 	 if (shuffledvectorend>shuffledvectorbeg){
		var t=shuffledvectorend;
		shuffledvectorend=shuffledvectorbeg;
		shuffledvectorbeg=t;
	}
}


function toslide(el,t,f) {
	lastslidenum.push(f);
	$('#slide'+f).hide()
	if (el=="pred")
	   if(t-1==shuffledvectorend) t=shuffledvector[t-1]; 
	   else {
 	   	var p=shuffledvector.indexOf(t);
		if(p==-1) t=t-1;
		else if (p==shuffledvectorbeg)t=p-1;
		else t=shuffledvector[p-1]; 
	}
	if (el=="next"){
	   if (shuffledvectorend<shuffledvectorbeg){
		   if(t+1==shuffledvectorend) {
			shuffledvectorend=shuffledvectorbeg;
			shuffledvectorbeg=t+1;
			t=shuffledvector[t+1]; 
		   }		
	   }else{
 	   	var p=shuffledvector.indexOf(t);
		if(p==-1) t=t+1;
		else if (p==shuffledvectorend)t=p+1;
		else t=shuffledvector[p+1]; 
		}
	}
	if (typeof (before_slide[t])=== "function") before_slide[t]();
	$('#slide'+t).show()	
}

function gotolocalurl(t){
    var k=t.indexOf("//");
    t=t.slice(k+2)
     var s=document.location.href
     k=s.lastIndexOf("/")
     s=s.substr(0,k+1)+t;
    window.open(s, '_blank').focus();

}

function gotourl(t,f) {
   if(f) 
    window.open(t, '_blank').focus();
   else 
    document.location.replace(t);	
}

function hideShape(s,cl=false){
if(cl) $('.'+s).hide();else $('#'+s).hide();
}

function showShape(s,cl=false){
if(cl) $('.'+s).show();else $('#'+s).show();
}

function unicode(s){
 var  sAscii, ascval
  sAscii = ''
  for (var x = 0; x<s.length;x++){
    ascval = s.charCodeAt(x)
    if (ascval < 0)   ascval = 65536 + ascval; 
    sAscii = sAscii+'&#'+ ascval+';'
  }
  return sAscii;
}

function Npadezh(k,s1,s2,s3){
if(k>=5 && k<20) return s3;
if (k%10==1) return s1;
if (k%10==2 || k%10==3 || k%10==4) return s2;
return s3;
}


function borderShape(s,b="green solid 6px"){
$('#'+s).css('border',b);
}



function onceClick(s){
	if (onceshape.indexOf(s)>=0) {
		return false;
	}
	onceshape.push(s);
	return true;
}




function initsafe(n){
    $("#"+n).attr('value',"");	
}


function opensafe(s,l,n,sn){

    var w = ""
    var d=0
    w='JABBERWOCKY'
    l=11
    s=document.getElementById(n).value;
	document.getElementById(n).value="";
    s=s.toUpperCase();
    if(s.length==l){
        s=s.replace(/[^A-Z]/g, "");
	if(s.length==l){
	        if(s==w) toslide(0,sn+1,sn); 
		else document.getElementById(n+'_error_click').click();

	}
   }
}


function spswap(c1,c2,p=true){
var y1=$('#'+c1)[0].style.top
var y2=$('#'+c2)[0].style.top
$('#'+c1).css('top',y2)
$('#'+c2).css('top',y1)
if(p){
var n1=(Number.parseInt(y1)-8)/9;
var n2=(Number.parseInt(y2)-8)/9;
console.log(n1,n2)
t=arr1[n1]
arr1[n1]=arr1[n2];
arr1[n2]=t;
console.log(arr1[n1],arr1[n2])
if(arr1[n1]==n1){ $('#'+c2).hide();$('#t'+c2.charAt(1)).show();sarr1++ }
if(n1!=n2 && arr1[n2]==n2){ $('#'+c1).hide();$('#t'+c1.charAt(1)).show();sarr1++}
}
}

function fun_runch1(){
if(chsl1==0) { chsl1=thisShape; $('#'+thisShape).css('background-color','red') }
else chsl2=thisShape;
if(chsl1!=0 && chsl2!=0){ spswap(chsl1,chsl2);
$('#'+chsl1).css('background-color','transparent')
$('#'+chsl2).css('background-color','transparent')
chsl1=0; chsl2=0
}
if (sarr1==10) showShape('nextans');
}

var ans72=['s7','s61','s4', 's5', 's2', 's9', 's6', 's3', 's8', 's10', 's1' ]
function fun_check7(){
hideShape('ans71'); hideShape('ans72'); hideShape('ans73'); hideShape('ans74'); showShape('ans70');
 hideShape('shape_13_4') ;
var i;
var p=[];
if($('#b7n2').attr('src')==='next.png') {tomenu(72);return;}
for(i=0;i<=10;i++)  
if  ($('#sel'+i).val()==='s0')break;
if (i!=11) {showShape('ans71');return;}

for(i=0;i<=10;i++) 
if(p[$('#sel'+i).val()]===true) break;
else p[$('#sel'+i).val()]=true;
if (i!=11) {showShape('ans72');return;}
p=0;
for(i=0;i<=10;i++) 
if ($('#sel'+i).val()===ans72[i]) {
$('#sel'+i).html('<option value="'+ans72[i]+'">'+$('#sel'+i+' option:selected').text()+"</option>");
$('#sel'+i).css('color','green')
}else p++;
if(p===0) {
showShape('ans74'); showShape('shape_13_4') ;
}else showShape('ans73')

}






var sarr1=0;
var tick=false, limer=false;
var S=Number.parseInt(getURLParameter('idtmp'));
history.pushState(null, null, "?idtmp=0")
if(S==14860) window.onload=function(){tick=true;limer=true;toslide(555,16,1);}; else window.onload=function(){toslide("",1,1);};
var chsl1=0, chsl2=0;
var arr1=[0,1,2,3,4,5,6,7,8,9]
before_slide[(7)]=function(){if(sarr1<10) {chsl1=0; chsl2=0;
arr1=[0,1,2,3,4,5,6,7,8,9]
	for (var i=0;i <=9;i++){
	j= getRandomInRange(0,i)
	arr1[i]=arr1[j]
	arr1[j]=i	}
for (var i=0;i <=9;i++){
var y2=8.79265 + i*9.012
y2=""+y2+"vh"
$('#p'+arr1[i]).css('top',y2)
}
}}
before_slide[(9)]=function() {
hideShape('mzsn1');
hideShape('mzsn2');
hideShape('mzsn3');
hideShape('mzsn4');
}
function fun_entersn(){
if (!tick) {
$("#mzsn1").show('slow'); setTimeout(function() { $("#mzsn1").hide('slow'); }, 2000);
}
else {
if(!limer) {$("#mzsn2").show('slow'); setTimeout(function() { $("#mzsn2").hide('slow'); }, 2000);}
else  {toslide('',17,9);}
}
}
function fun_entersn3(){
if (!tick) {
$("#mzsn3").show('slow'); setTimeout(function() { $("#mzsn3").hide('slow'); }, 2000);
}
else { if(!limer) {toslide('',15,9);}  else {
$("#mzsn4").show('slow'); setTimeout(function() { $("#mzsn4").hide('slow'); }, 2000);
}}
}
before_slide[(10)]=function() {
hideShape('tryb ');
}
function fun_nexttick(t){
if (!t) toslide('',11,10);
else
{
$("#tryb ").show('slow'); setTimeout(function() { $("#tryb ").hide('slow'); toslide('',9,10); }, 3000);
}
	
}
before_slide[(12)]=function(){hideShape("ans71"); hideShape("ans72"); hideShape("ans73"); hideShape("ans74"); hideShape("ans70"); hideShape("shape_13_4")}
before_slide[(13)]=function(){hideShape("ans71"); hideShape("ans72"); hideShape("ans73"); hideShape("ans74"); hideShape("ans70"); hideShape("shape_13_4")}
before_slide[(13)]=function(){tick=true;}
function fun_limer(){
document.location.replace("limer.html");
}
initsafe('safe');
safeid='safe';
