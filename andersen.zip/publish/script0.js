var lastslidenum=[]
var safeid=""
var thisshape=""
var thisslide=0
var onceshape=[]
var before_slide=[]
var shuffledvector=[]               
var shuffledvectorbeg=0, shuffledvectorend=0

function getURLParameter(name) {
  return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
}

function getRandomInRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function anew(a=1){
	if (a!=1 ) {
		var ok = confirm("Вы действительно хотите начать всё заново?");
	} else ok=true;
	if (ok) document.location.replace("index.html");
}

function startgame() {
if (safeid>"") initsafe(safeid);
$('#slide1').hide()
console.log('s=', getURLParameter('s'));
if(getURLParameter('s')) toslide(0,getURLParameter('s'),2); else toslide(0,2,1);
}

function returnslide(f,op="") {
var t=0;
if (lastslidenum.length>0){
	if(op=="next"){
	  t=lastslidenum.pop();
          $('#slide'+f).hide()	
	  toslide(op,t,t);
        }
        else  {
	        $('#slide'+f).hide()	
	        $('#slide'+lastslidenum.pop()).show()	
        }
}
}

function SlidesShuffle(a=0,b=0){
	if(a==0 || b==0) {
	  shuffledvector=[];
	  shuffledvectorbeg=0;	
	  shuffledvectorend=0;
	  return;               
	}
   	var j;
	shuffledvectorbeg=b;	
	shuffledvectorend=a;
	for (var i=a;i <=b;i++){
      		j= getRandomInRange(a,i)
      		shuffledvector[i]=shuffledvector[j]
      		shuffledvector[j]=i
	}
}

function enterShuffled(){
 	 if (shuffledvectorend>shuffledvectorbeg){
		var t=shuffledvectorend;
		shuffledvectorend=shuffledvectorbeg;
		shuffledvectorbeg=t;
	}
}


function toslide(el,t,f=0) {
        if (f==0) f=thisslide;
	lastslidenum.push(f);
	$('#slide'+f).hide()
	if (el=="pred")
	   if(t-1==shuffledvectorend) t=shuffledvector[t-1]; 
	   else {
 	   	var p=shuffledvector.indexOf(t);
		if(p==-1) t=t-1;
		else if (p==shuffledvectorbeg)t=p-1;
		else t=shuffledvector[p-1]; 
	}
	if (el=="next"){
	   if (shuffledvectorend<shuffledvectorbeg){
		   if(t+1==shuffledvectorend) {
			shuffledvectorend=shuffledvectorbeg;
			shuffledvectorbeg=t+1;
			t=shuffledvector[t+1]; 
		   }		
	   }else{
 	   	var p=shuffledvector.indexOf(t);
		if(p==-1) t=t+1;
		else if (p==shuffledvectorend)t=p+1;
		else t=shuffledvector[p+1]; 
		}
	}
	if (typeof (before_slide[t])=== "function") before_slide[t]();
	thisslide=t;
	$('#slide'+t).show()	
}

function gotolocalurl(t){
    var k=t.indexOf("//");
    t=t.slice(k+2)
     var s=document.location.href
     k=s.lastIndexOf("/")
     s=s.substr(0,k+1)+t;
    window.open(s, '_blank').focus();

}

function gotourl(t,f) {
   if(f) 
    window.open(t, '_blank').focus();
   else 
    document.location.replace(t);	
}

function hideShape(s,cl=false){
if(cl) $('.'+s).hide();else $('#'+s).hide();
}

function showShape(s,cl=false){
if(cl) $('.'+s).show();else $('#'+s).show();
}

function unicode(s){
 var  sAscii, ascval
  sAscii = ''
  for (var x = 0; x<s.length;x++){
    ascval = s.charCodeAt(x)
    if (ascval < 0)   ascval = 65536 + ascval; 
    sAscii = sAscii+'&#'+ ascval+';'
  }
  return sAscii;
}

function Npadezh(k,s1,s2,s3){
if(k>=5 && k<20) return s3;
if (k%10==1) return s1;
if (k%10==2 || k%10==3 || k%10==4) return s2;
return s3;
}


function borderShape(s,b="green solid 6px"){
$('#'+s).css('border',b);
}



function onceClick(s){
	if (onceshape.indexOf(s)>=0) {
		return false;
	}
	onceshape.push(s);
	return true;
}




function initsafe(n){
    $("#"+n).attr('value',"");	
}


function opensafe(s,l,n,sn){

    var w = ""
    var v = s.charCodeAt(l)-65
    var d=0
    for(var  i = 0;i<l;i++){
	d=(s.charCodeAt(i)-65+22-3-v)*3
        w=w+String.fromCharCode((d-4+11)%11+48)
    }
    s=document.getElementById(n).value;
	document.getElementById(n).value="";
    if(s.length==l){
        s=s.replace(/[^0-9]/g, "");
	if(s.length==l){
	        if(s==w) toslide(0,sn+1,sn); 
		else document.getElementById(n+'_error_click').click();

	}
   }
}


function spswap(c1,c2,p=true){
var y1=$('#'+c1)[0].style.top
var y2=$('#'+c2)[0].style.top
$('#'+c1).css('top',y2)
$('#'+c2).css('top',y1)
if(p){
var n1=(Number.parseInt(y1)-8)/9;
var n2=(Number.parseInt(y2)-8)/9;
console.log(n1,n2)
t=arr1[n1]
arr1[n1]=arr1[n2];
arr1[n2]=t;
console.log(arr1[n1],arr1[n2])
if(arr1[n1]==n1){ $('#'+c2).hide();$('#t'+c2.charAt(1)).show();sarr1++ }
if(n1!=n2 && arr1[n2]==n2){ $('#'+c1).hide();$('#t'+c1.charAt(1)).show();sarr1++}
}
}

function fun_runch1(){
if(chsl1==0) { chsl1=thisShape; $('#'+thisShape).css('background-color','red') }
else chsl2=thisShape;
if(chsl1!=0 && chsl2!=0){ spswap(chsl1,chsl2);
$('#'+chsl1).css('background-color','transparent')
$('#'+chsl2).css('background-color','transparent')
chsl1=0; chsl2=0
}
if (sarr1==10) showShape('nextans');
}




function crw_input_control(evn, pattern) {

	evn = evn || window.event;
	var sender = evn.target || evn.srcElement;
	var isIE = document.all;
	var str=sender.value;
	var isize=sender.size;
	//console.log(isize);
	var str1=str.toUpperCase();
	if (str1=="ЭЛИЗА"&&isize==5) {str1="ЭЛЬЗА";
        sender.value=str1;   }
	if (pattern=='' ) {sender.value='';$('#'+sender.id).attr('value',''); $('#'+sender.id).css('color','black'); 
	$('#'+sender.id).css('text-decoration','none');$('#'+sender.id).attr('placeholder','')
	return;}                                       

	if (sender.tagName.toUpperCase()=='INPUT')
	{
		var keyPress = isIE ? evn.keyCode : evn.which;

		if (keyPress < 32 || evn.altKey || evn.ctrlKey){
                  if(keyPress==13)  {
inpword2(anstext.value);return false;}           
			return true;}

	    var symbPress = String.fromCharCode(keyPress);
        	    if (!pattern.test(symbPress))
	    	{$('#'+sender.id).attr('placeholder','А-Яа-я');return false;}

       if (str.length>isize-1) return false;

	}

	return true;

}


function inpword(sn)
{  var re = /^(\d*)\(по\s(.).*\.\,\s?(\d*).*\)/;
if(sn.id>"") {sn=sn.id;sn=sn.substring(7)} 
console.log('numword'+sn);
s=document.getElementById('numword'+sn).title;
var nameList = s.match(re);
if(document.getElementById('numword'+nameList[1]).className>"") return;
var ans=document.getElementById("ans");
var k=s.indexOf(").") 
$('#anstext').click();
ans.getElementsByTagName('p')[0].innerText=s.substr(0,k+1);
document.getElementById("anstext").size=nameList[3];
document.getElementById("anstext").value="";
if(nameList[2]=='в')
document.getElementById("anstext").min=nameList[1];
else
document.getElementById("anstext").min=-nameList[1];
ans.hidden=false;
$('#ans').show();
document.getElementById("anstext").focus();
}
var anscrw=['нет','ЗОНТИК','ЛОЖКА','ГАНС','КОЗЛОНОГ','КРАПИВА','ЧУРБАН','ЭЛЬЗА','ПЕТЕР','СОЛОВЕЙ','ЯЛЬМАР', 'ВЕЧНОСТЬ','СВИНОПАС' ,'МАЙЯ'];

function inpword2(w)
{  
var chok=false;
w=w.toUpperCase();
w=w.replace('Ё','Е');
var numword=document.getElementById("anstext").min;
if(w=="ЭЛИЗА"&&numword==7)w="ЭЛЬЗА";
anstext.value=w;
ans.hidden=true;
w=w.trim();
w=w.substring(0,document.getElementById("anstext").size);

var vert=true;
var isize=document.getElementById("anstext").size;

if (w===anscrw[Math.abs(numword)]) chok=true;
if(document.getElementById('numword'+Math.abs(numword)).className>"") return;
if (numword<0) {vert=false;numword=-numword;}
var tr2 = document.getElementById('crosw').getElementsByTagName('tr');
var j=0;
var q="-";
if(vert)
for(var i=0;i<isize;i++){
    var c=w.substring(i,i+1).toUpperCase();
    if (c=='Ё') c='Е';
if(c>='а' && c<='я' ||c>='А' && c<='Я' ||c=='ё'||c=='Ё') {  

    	var td2 = tr2[getcoord(numword,0)+j].getElementsByTagName('td');
	var em=td2[0+getcoord(numword,1)].getElementsByTagName('em');
	var st=td2[0+getcoord(numword,1)].getElementsByTagName('strong');	em[0].innerText=c;
	if (em[0].innerText=='') td2[0+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em></em>'+c;
	else if (st[0].innerText=='') td2[0+getcoord(numword,1)].innerHTML='<em>'+em[0].innerHTML+'</em><strong></strong>'+c;
	else if (st[0].innerText!=em[0].innerText) {td2[0+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em><span>'+c+'</span>';q='';}
	else td2[0+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em>'+c;


	j=j+1;q=q+c;}
if(chok)
{document.getElementById('numword'+numword).className='numwordsel'; 
}else document.getElementById('numword'+numword).className=''; 
}
else 
for(var i=0;i<isize;i++){
    var c=w.substring(i,i+1).toUpperCase();
    if (c=='Ё') c='Е';
if(c>='а' && c<='я' ||c>='А' && c<='Я' ||c=='ё'||c=='Ё') {  
var td2 = tr2[getcoord(numword,0)].getElementsByTagName('td');    	
	var em=td2[j+getcoord(numword,1)].getElementsByTagName('em');
	var st=td2[j+getcoord(numword,1)].getElementsByTagName('strong');
	st[0].innerText=c;
	if (em[0].innerText=='') td2[j+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em></em>'+c;
	else if (st[0].innerText=='') td2[j+getcoord(numword,1)].innerHTML='<em>'+em[0].innerHTML+'</em><strong></strong>'+c;
	else if (st[0].innerText!=em[0].innerText) {td2[j+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em><span>'+c+'</span>';q='';}
	else td2[j+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em>'+c;

	j=j+1;q=q+c;} 
if(chok)
{document.getElementById('numword'+numword).className='numwordsel'; 
}else document.getElementById('numword'+numword).className=''; 
}
if(chok){
document.getElementById('numword'+numword).className='numwordsel'; 
p10++;
if(p10==13){$('#ret2').show(); ps7=1;}  
}
else document.getElementById('numword'+numword).className=''; 
}	     

function getcoord(n,d){
var dstr=document.getElementById("poswords").innerHTML.trim()
return dstr.charCodeAt(2*parseInt(n)-1+d)-64
}

function field_input_control(evn, pattern) {

	evn = evn || window.event;
	var sender = evn.target || evn.srcElement;
	var isIE = document.all;
	var str=sender.value;
	var chr;
	var isize=sender.size;
	if($('#'+sender.id).attr('readonly')) return;
	if (pattern=='' ) {sender.value='';$('#'+sender.id).attr('value',''); $('#'+sender.id).css('color','black'); 
	$('#'+sender.id).css('text-decoration','none');$('#'+sender.id).attr('placeholder','')
	return;}                                       
	if (sender.tagName.toUpperCase()=='INPUT')
	{
		var keyPress = isIE ? evn.keyCode : evn.which;

		if (keyPress < 32 || evn.altKey || evn.ctrlKey){
			return false;}

	    var symbPress = String.fromCharCode(keyPress);

	    if (!pattern.test(symbPress))
	    	{$('#'+sender.id).attr('placeholder','А-Яа-я');return false;}

       if (str.length>isize-1) return false;

	chr=symbPress.toUpperCase();
	if (chr==='Ё') chr='Е';
	if (sender.id=="safe1"&&chr==='Е') chr='Ё';
	sender.value=sender.value.toUpperCase()+chr;
	var fg='';
        $('#'+sender.id).attr('value',sender.value)
        $('#'+sender.id).css('color','black')
	$('#'+sender.id).css('text-decoration','none');
	return false;
      }

}

function change_input_control(evn) {

	evn = evn || window.event;
	var sender = evn.target || evn.srcElement;
	var isIE = document.all;
	var str=sender.value;
	var isize=sender.size;
        sender.value=$('#'+sender.id).attr('value').toUpperCase()
        str=sender.value; 
	if(str=="УТЕНОК")str="УТЁНОК";
        $('#'+sender.id).attr('value',sender.value)

	return true;

}




var ps1=0,ps2=0,ps3=0,ps4=0,ps5=0,ps6=0,ps7=0;
var d15=0,t15=[0,1,2,3,4,5,6,7,8,9,10,11,12];
var d17=0,t17=[0,1,2,3,4,5,6];
var t12=[0,0,0,0,0,0,0];
before_slide[(2)]=function(){
ps1=ps2=ps3=ps4=ps5=ps6=ps7=0;
}
before_slide[(3)]=function(){
if(ps1==0) $("#ps01").show(); else $("#ps01").hide();
if(ps2==0) $("#ps02").show(); else $("#ps02").hide();
if(ps3==0) $("#ps03").show(); else $("#ps03").hide();
if(ps4==0) $("#ps04").show(); else $("#ps04").hide();
if(ps5==0) $("#ps05").show(); else $("#ps05").hide();
if(ps6==0) $("#ps06").show(); else $("#ps06").hide();
if(ps7==0) $("#ps07").show(); else $("#ps07").hide();
}
function fun_click2(){if (ps1==0)toslide(0,15,3) ;else toslide(0,16,3) }
function fun_retmenu(n){
if(ps1+ps2+ps3+ps4+ps5+ps6+ps7<7) toslide(0,3,n);
else toslide(0,18,n);
}
before_slide[(4)]=function(){
if(ps4==0) $("#zont").hide();
}
function fun_click4(n=0){
if(n==1) {$("#"+thisShape).css("border","solid 4px green"); $("#zont").show();}
else {
$("#"+thisShape).hide();
}
}
before_slide[(5)]=function(){
if(ps4==0) $("#zont2").hide();
}
function fun_click5(n=0){
if(n==1) {$("#"+thisShape).css("border","solid 4px green"); $("#zont2").show();}
else {
$("#"+thisShape).hide();
}
}
before_slide[(6)]=function(){
if(ps4==0) $("#zont3").hide();
}
function fun_click6(n=0){
if(n==1) {$("#"+thisShape).css("border","solid 4px green"); $("#zont3").show();}
else {
$("#"+thisShape).hide();
}
}
before_slide[(7)]=function(){
if(ps4==0) $("#zont4").hide();
}
function fun_click7(n=0){
if(n==1) {$("#"+thisShape).css("border","solid 4px green"); $("#zont4").show();}
else {
$("#"+thisShape).hide();
}
}
before_slide[(8)]=function(){
if(ps4==0) $("#zont5").hide();
}
function fun_click8(n=0){
if(n==1) {$("#"+thisShape).css("border","solid 4px green"); $("#zont5").show();}
else {
$("#"+thisShape).hide();
}
}
before_slide[(9)]=function(){
if(ps4==0) $("#zont6").hide();
}
function fun_click9(n=0){
if(n==1) {$("#"+thisShape).css("border","solid 4px green"); $("#zont6").show();ps4=1;}
else {
$("#"+thisShape).hide();
}
}
var p10=0;
before_slide[(10)]=function(){
hideShape('ans');
if(ps7==0)$('#ret2').hide(); else $('#ret2').show();
}
before_slide[(11)]=function(){
if(ps2==0){ $("#msg11").hide();
$("#key").hide();
}
}
var d11=0,t11=[0,0,0,0,0,0, 0,0],p11=0, zpos=[0,13,8,14,10,9,11,12];
function swap11(n,m){
var t,k,d;
t=zpos.indexOf(n);
d=zpos.indexOf(m);
k=zpos[t];zpos[t]=zpos[d];zpos[d]=k;
console.log(t15);
var t1=$('#z'+n)[0].style.top
var t2=$('#z'+m)[0].style.top
var l1=$('#z'+n)[0].style.left
var l2=$('#z'+m)[0].style.left
$('#z'+n).css('top',t2);
$('#z'+m).css('top',t1);
$('#z'+n).css('left',l2);
$('#z'+m).css('left',l1);
}
function fun_click11(t){
var l,k;
var d=t;
if(d11==0 ||  d11<8 && d<8 || d11>7&&d>7) {d11=d;
for(var i=1;i<=14;i++) if(i==d11)$('#z'+i).css('border', "2px solid gray");else $('#z'+i).css('border', "");
return
}
if(d11%7==d%7) {
if(d11<d) {k=d;d=d11;d11=k }
if(t11[d]==true){}else p11++;
t11[d]=true;
swap11(zpos[d],d11);
t=$('#z'+d)[0].style.top
l=parseInt(t)
t=''+(+l+15)+"vh";
if(d==3) t=''+(+l+1)+"vh";
$('#z'+d11).css('top',t);
t=$('#z'+d)[0].style.left
l=parseInt(t)
t=''+(+l+0.5)+"vh";
if(d==3) t=''+(+l-15)+"vh";
$('#z'+d11).css('left',t);
console.log(t);
d11=0;
if(p11==7){$('#key').show(); $('#msg11').show();ps2=1;}
for(var i=1;i<=14;i++) $('#z'+i).css('border', "");
//$('#z'+d11).css('top' , $('#z'+d).css('top' ));
//$('#z'+d).css('border', "2px solid green");
//$('#z'+d11).css('border', "none");
} else {
d11=d;
for(var i=1;i<=14;i++) if(i==d11)$('#z'+i).css('border', "2px solid gray");else $('#z'+i).css('border', "");
}
}
 
 
var q12=0;var sl12=0;
before_slide[(12)]=function(){
if(ps6==1) {
$("#next4").show();
return;}
q12=0;
$("#next4").hide();
$("#vs1").hide(); $("#vs2").hide();
$("#vs3").hide();
$("#qt1").hide(); $("#qt2").hide();
$("#qt3").hide();
showAll();
$("#qt0").show();
}
function fun_click12(n=0){
if(q12==0&&n>=0) return;
if(n<0) {
if(t12[-n]) clearAll(-n); else showAll();
/*if(t12[1]&&t12[2] &&t12[3]) $("#next4").show();
Lse*/
$("#next4").hide(); $("#next5").hide();
$("#qt"+(-n)).show();
q12=-n;
return;
}
if(n==0) {
$("#"+thisShape).hide();
return;
}
if(n>0) {
if(n==q12) {
t12[n]=true;
showAll(); if(ps6==0){$("#next4").hide(); $("#next5").hide();}
else {$("#next4").show(); $("#next5").show();}
if(t12[1]&&t12[2] &&t12[3]) $("#next4").show(); else $("#qt0").show();
if(t12[4]&&t12[5] &&t12[6]) {$("#next5").show();ps6=1} else $("#qt100").show();
q12=0;
} else  $("#"+thisShape).hide();
}
}
function showAll(){
for(var i=0;i<=6;i++) $("#qt"+i).hide();
$("#qt100").hide();
for(var i=1;i<=20;i++) $("#qy"+i).show();
for(var i=1;i<=6;i++)
if(t12[i]) $("#vs"+i).show(); else $("#vs"+i).hide();
}
function clearAll(n){
$("#qt1").hide(); $("#qt2").hide();
$("#qt3").hide(); $("#qt0").hide();
$("#qt100").hide();
for(var i=1;i<=20;i++) $("#qy"+i).hide();
for(var i=1;i<=6;i++)
if(t12[i]) $("#vs"+i).show(); else $("#vs"+i).hide();
$("#qy"+n).show();
}
before_slide[(13)]=function(){
if(ps6==1) {
$("#next5").show();
return;}
t12[4]=false;
q12=0;
$("#next5").hide();
$("#vs4").hide(); $("#vs5").hide();
$("#vs6").hide();
$("#qt4").hide(); $("#qt5").hide();
$("#qt6").hide();
showAll();
$("#qt100").show();
}
//утёнок герда  свинопас  принцесса разбойница  русалочка
before_slide[(14)]=function(){
if(ps5==0) $("#tomenu14").hide();else  $("#tomenu14").show();
}
function fun_check14(){
	var p14=0;
	if( $('#safe1').attr('value')=='УТЁНОК') {p14++ ;$('#safe1').attr('readonly',1) ; $('#safe1').css('color', 'green') ;} else if($('#safe1').attr('value')>'') $('#safe1').css('color', 'red') ;
	if( $('#safe2').attr('value')=='РУСАЛОЧКА') {p14++;$('#safe2').attr('readonly',1) ; $('#safe2').css('color', 'green') ;} else if($('#safe2').attr('value')>'') $('#safe2').css('color', 'red') ;
	if( $('#safe3').attr('value')=='СВИНОПАС') {p14++; $('#safe3').attr('readonly',1) ;$('#safe3').css('color', 'green') ;} else if($('#safe3').attr('value')>'') $('#safe3').css('color', 'red') ;
	if( $('#safe4').attr('value')=='ГЕРДА') {p14++;$('#safe4').attr('readonly',1) ; $('#safe4').css('color', 'green') ;} else if($('#safe4').attr('value')>'') $('#safe4').css('color', 'red') ;
	if( $('#safe5').attr('value')=='ПРИНЦЕССА') {p14++;$('#safe5').attr('readonly',1) ; $('#safe5').css('color', 'green') ;} else if($('#safe5').attr('value')>'') $('#safe5').css('color', 'red') ;
	if( $('#safe6').attr('value')=='РАЗБОЙНИЦА') {p14++;$('#safe6').attr('readonly',1) ; $('#safe6').css('color', 'green') ;} else if($('#safe6').attr('value')>'') $('#safe6').css('color', 'red') ;
	if(p14==6) {$('#tomenu14').show() ;ps5=1}
}
before_slide[(15)]=function(){
//for(var i=1;i<=12;i++) t15[i]=i;
for(var i=1;i<12;i++){
swap15(i, getRandomInRange(i+1,12));
}
d15=0;
}
function swap15(n,m){
var t;
t=t15[n];t15[n]=t15[m];t15[m]=t;
console.log(t15);
var t1=$('#w'+n)[0].style.top
var t2=$('#w'+m)[0].style.top
var l1=$('#w'+n)[0].style.left
var l2=$('#w'+m)[0].style.left
$('#w'+n).css('top',t2);
$('#w'+m).css('top',t1);
$('#w'+n).css('left',l2);
$('#w'+m).css('left',l1);
}
function fun_click15(n){
if(d15==0) d15=n;
else{
swap15(n,d15);
d15=0;
if(check15()) {toslide(0,16,15);ps1=1;}
}
}
function check15(){
for(var i=1;i<=12;i++)
if (t15[i]!=i) return false;
return true;
}
before_slide[(17)]=function(){
if(ps3==1) return;
//for(var i=1;i<=12;i++) t15[i]=i;
$("#ret14").hide();
for(var i=1;i<6;i++){
swap17(i, getRandomInRange(i+1,6));
}
d17=0;
}
function swap17(n,m){
var t;
t=t17[n];t17[n]=t17[m];t17[m]=t;
var t1=$('#q'+n)[0].style.top
var t2=$('#q'+m)[0].style.top
$('#q'+n).css('top',t2);
$('#q'+m).css('top',t1);
}
function fun_click17(n){
if($('#q'+n)[0].style.left<"6") return;
if(d17==0) d17=n;
else{
swap17(n,d17);
if(t17[n]==n) $('#q'+n).css('left',"54vh");
if(t17[d17]==d17) $('#q'+d17).css('left',"54vh");
d17=0;
if(check17()) {$("#ret14").show();
ps3=1;}
}
for(var i=1;i<=6;i++)
if(i==d17) $('#q'+i).css('border',"solid 2px white") ;else $('#q'+i).css('border',"none") ;
}
function check17(){
for(var i=1;i<=6;i++)
if (t17[i]!=i) return false;
return true;
}
